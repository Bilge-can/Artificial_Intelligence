#Favori meyvelerinizin olduğu bir liste oluşturunuz ve bu listede 5 adet meyveniz bulunsun.
#Listenin adı favori_meyveler şeklinde tanımlansın. if-else yapısını kullanarak örnekte verilen
#meyvelerin favori listenizde olup olmadığını kontrol ediniz. Örnek meyveler; elma, armut,
#karpuz, kavun, muz, portakal, çilek, vişne, kiraz ve mandalina (20p).


favori_meyveler = ["karpuz", "kavun", "mandalina", "muz", "vişne"]

if "karpuz" in favori_meyveler:
    print("Karpuz favori meyveleriniz arasında bulunuyor!")
else:
    print("Karpuz favori meyveleriniz arasında bulunmuyor.")

if "vişne" in favori_meyveler:
    print("Vişne favori meyveleriniz arasında bulunuyor!")
else:
    print("Vişne favori meyveleriniz arasında bulunmuyor.")

if "armut" in favori_meyveler:
    print("Mandalina favori meyveleriniz arasında bulunuyor!")
else:
    print("Mandalina favori meyveleriniz arasında bulunmuyor.")

if "mandalina" in favori_meyveler:
    print("Mandalina favori meyveleriniz arasında bulunuyor!")
else:
    print("Mandalina favori meyveleriniz arasında bulunmuyor.")

if "muz" in favori_meyveler:
    print("Mandalina favori meyveleriniz arasında bulunuyor!")
else:
    print("Mandalina favori meyveleriniz arasında bulunmuyor.")